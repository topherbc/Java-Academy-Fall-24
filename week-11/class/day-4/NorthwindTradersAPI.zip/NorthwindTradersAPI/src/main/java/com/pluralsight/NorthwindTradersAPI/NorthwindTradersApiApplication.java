package com.pluralsight.NorthwindTradersAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NorthwindTradersApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NorthwindTradersApiApplication.class, args);
	}

}
